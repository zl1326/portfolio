/************************************************************
* Nom ........ : MinishellSE.c
* Rôle ....... : Mini-shell (avec arrière-plan et auto-complétion)
* Auteur ..... : LAIDANI Zakariya
* Version .... : V6 du 28/07/2026 (ajout arrière-plan + auto-complétion)
* Licence .... : IED Paris 8, Chapitre 10 - Le Projet Final
*
* Compilation : gcc -Wall -o MinishellSE MinishellSE.c -lreadline
* Usage ...... : ./MinishellSE
* Dépendance.. : libreadline-dev (apt-get install libreadline-dev)
************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <errno.h>
#include <readline/readline.h> // Auto-complétion des noms de fichiers (TAB)
#include <readline/history.h> // Historique des commandes tapées

int main() {
    char *ligne; // Ligne retournée par readline() (allouée dynamiquement)
    char *mots[64]; // Tableau des arguments (max 64 mots)
    int n; // Compteur de mots

    printf("--- MinishellSE (avec pipes, arrière-plan et auto-complétion) ---\n");

    while (1) {

        int pid_termine;
        while ((pid_termine = waitpid(-1, NULL, WNOHANG)) > 0) { // Récupère les procédures en arrière-plan terminées, évite les zombies
            printf("[Terminé] Processus en arrière-plan %d terminé\n", pid_termine);
        }

        char ici[1024];
        if (getcwd(ici, sizeof(ici)) == NULL) {
            fprintf(stderr, "Erreur getcwd : %s (errno = %d)\n", strerror(errno), errno);
            strcpy(ici, "?");
        }
        char prompt[1100];
        snprintf(prompt, sizeof(prompt), "[%s]> ", ici);

        ligne = readline(prompt); // readline() gère nativement TAB pour l'auto-complétion
        if (ligne == NULL) {
            printf("\n"); // Ctrl+D (EOF) : sortie de facon propre et controlée, équivalent à fgets == NULL
            break;
        }

        if (ligne[0] != '\0') {
            add_history(ligne); // On garde un historique des commandes non vides
        }

        n = 0;
        char *p = strtok(ligne, " ");
        while (p != NULL) {
            mots[n++] = p;
            p = strtok(NULL, " ");
        }
        mots[n] = NULL;

        if (n == 0) {
            free(ligne); // readline() alloue la ligne, il faut la libérer nous-même
            continue;
        }

        if (strcmp(mots[0], "monexit") == 0) {
            printf("Sortie du shell en cours, veuillez patientez...\n");
            free(ligne);
            return 0;
        }

        if (strcmp(mots[0], "exit") == 0) {
            free(ligne);
            break;
        }

        if (strcmp(mots[0], "moncd") == 0) {
            char *destination;
            if (n == 1) {
                destination = getenv("HOME");
                if (destination == NULL) destination = "/tmp";
            }
            else if (n > 2) {
                printf("Erreur : moncd prend un seul dossier !\n");
                free(ligne);
                continue;
            }
            else {
                destination = mots[1];
            }

            if (chdir(destination) != 0) {
                fprintf(stderr, "Erreur moncd : %s (errno = %d)\n", strerror(errno), errno);
            }
            free(ligne);
            continue;
        }

        int arriere_plan = 0;
        if (n > 0 && strcmp(mots[n - 1], "&") == 0) { // Détection du "&" en fin de ligne
            arriere_plan = 1;
            mots[n - 1] = NULL; // On retire le "&" des arguments
            n--;
            if (n == 0) {
                free(ligne); // Ligne composée uniquement de "&", rien à exécuter
                continue;
            }
        }

        int pos_pipe = -1;
        for (int i = 0; mots[i] != NULL; i++) {
            if (strcmp(mots[i], "|") == 0) {
                pos_pipe = i;
                break;
            }
        }

        if (pos_pipe != -1) {

            mots[pos_pipe] = NULL; // On coupe le tableau en deux autour du "|"
            char **cmd_gauche = mots;
            char **cmd_droite = mots + pos_pipe + 1;

            int fd[2];
            if (pipe(fd) == -1) { // Création du pipe AVANT le fork()
                fprintf(stderr, "Erreur pipe : %s (errno = %d)\n", strerror(errno), errno);
                free(ligne);
                continue;
            }

            int id_gauche = fork(); // Fork du processus gauche (écrit dans le pipe)
            if (id_gauche == -1) {
                fprintf(stderr, "Erreur fork (gauche) : %s (errno = %d)\n", strerror(errno), errno);
                close(fd[0]);
                close(fd[1]);
                free(ligne);
                continue;
            }
            if (id_gauche == 0) {
                if (dup2(fd[1], 1) == -1) { // Redirige stdout vers fd[1]
                    fprintf(stderr, "Erreur dup2 (gauche) : %s (errno = %d)\n", strerror(errno), errno);
                    exit(1);
                }
                close(fd[0]);
                close(fd[1]);
                if (execvp(cmd_gauche[0], cmd_gauche) == -1) {
                    fprintf(stderr, "Commande inconnue : %s -> %s (errno = %d)\n", cmd_gauche[0], strerror(errno), errno);
                    exit(1);
                }
            }

            int id_droit = fork(); // Fork du processus droit (lit depuis le pipe)
            if (id_droit == -1) {
                fprintf(stderr, "Erreur fork (droit) : %s (errno = %d)\n", strerror(errno), errno);
                close(fd[0]);
                close(fd[1]);
                waitpid(id_gauche, NULL, 0);
                free(ligne);
                continue;
            }
            if (id_droit == 0) {
                if (dup2(fd[0], 0) == -1) { // Redirige stdin vers fd[0]
                    fprintf(stderr, "Erreur dup2 (droit) : %s (errno = %d)\n", strerror(errno), errno);
                    exit(1);
                }
                close(fd[0]);
                close(fd[1]);
                if (execvp(cmd_droite[0], cmd_droite) == -1) {
                    fprintf(stderr, "Commande inconnue : %s -> %s (errno = %d)\n", cmd_droite[0], strerror(errno), errno);
                    exit(1);
                }
            }

            close(fd[0]); // Fermeture obligatoire des deux côtés du pipe dans le parent
            close(fd[1]);

            if (arriere_plan) {
                printf("[Arrière-plan] pipe lancé (PIDs %d et %d)\n", id_gauche, id_droit);
            } else {
                wait(NULL); // On attend la fin des deux fils
                wait(NULL);
            }

        } else {
            int id = fork(); // Bloc commande externe (ls, pwd, etc.)
            if (id == 0) {
                for (int i = 0; mots[i] != NULL; i++) {
                    if (strcmp(mots[i], ">") == 0) { // Redirection de sortie
                        int fd = open(mots[i+1], O_WRONLY | O_CREAT, 0644);
                        if (fd == -1) {
                            fprintf(stderr, "Erreur open (Cas sortie) : %s (errno = %d)\n", strerror(errno), errno);
                            exit(1);
                        }
                        if (dup2(fd, 1) == -1) {
                            fprintf(stderr, "Erreur dup2 (Cas sortie) : %s (errno = %d)\n", strerror(errno), errno);
                            close(fd);
                            exit(1);
                        }
                        close(fd);
                        mots[i] = NULL;
                        break;
                    }

                    if (strcmp(mots[i], "<") == 0) { // Redirection d'entrée
                        int fd = open(mots[i+1], O_RDONLY);
                        if (fd == -1) {
                            fprintf(stderr, "Erreur open (Cas entrée) : %s (errno = %d)\n", strerror(errno), errno);
                            exit(1);
                        }
                        if (dup2(fd, 0) == -1) {
                            fprintf(stderr, "Erreur dup2 (Cas entrée) : %s (errno = %d)\n", strerror(errno), errno);
                            close(fd);
                            exit(1);
                        }
                        close(fd);
                        mots[i] = NULL;
                        break;
                    }
                }

                if (execvp(mots[0], mots) == -1) {
                    fprintf(stderr, "Commande inconnue : %s -> %s (errno = %d)\n", mots[0], strerror(errno), errno);
                    exit(1);
                }
            }
            else if (id > 0) {
                if (arriere_plan) { // Le parent n'attend pas si arrière-plan
                    printf("[Arrière-plan] processus lancé avec le PID %d\n", id);
                } else {
                    wait(NULL); // Le parent attend l'enfant
                }
            }
            else {
                fprintf(stderr, "Erreur lors de la création du processus : %s (errno = %d)\n", strerror(errno), errno);
            }
        }

        free(ligne); // On libère la ligne allouée par readline() à chaque tour
    }
    return 0;
}